﻿HIS extract (HISGENX)
Pack: facts
HIS SetupID: 010266
HIS ProjectID: 17
Period: 2026-11-02 .. 2026-11-02 inclusive
Extracted (UTC): 2026-11-17 12:25:46Z

Identity is SetupID + ProjectID (every CSV + zip name). Do not treat the zip
filename as a VERITA hospital. Inner CSV names stay NN_Table.csv.

Facts are one zip per day. They include 35_ActivityTransaction.csv from measured HIS
clocks and quantities, 39_ConsumptionItem.csv (consumables, implants, medicine by item)
and 40_StaffTime.csv (OR team, OP/ER doctor, ward nursing minutes). Quantities only:
invoice price is not cost. Each day carries every item and minute of the encounters
admitted or invoiced that day; rows are keyed by sourceRef, so re-sent rows update.
Import remaps SetupID-ProjectID codes onto the VERITA hospital you pick.

00_manifest.csv: 1 rows
Facts 2026-11-02 .. 2026-11-03 (SQL end exclusive)
32_Patient.csv: 3,324 rows
Drg on IP: 9927 admissions (0 from INP_AdmissionDRGList).
Drg on OP: 0 appointments from HIS_ApprovalDRG.
ER links by InvoiceNo: 36647.
ER links by AppointmentID: 40148.
ER encounters: 367 linked by AppointmentID, 0 linked by InvoiceNo, 0 with no appointment. 0 AppointmentID values had no appointment for the same patient; 2 assessments shared an appointment with another.
33_Encounter.csv: 3,880 rows
Invoice lines with no appointment, admission or ER assessment, not loaded: 0.
RefundTransaction 84 lines: 0 on cancelled refunds, 14 with no encounter. Not written as revenue.
37_RefundTransaction.csv: 84 rows
InvoicePackageItem 2311 lines: 0 with no encounter. Not written as services or revenue.
38_InvoicePackageItem.csv: 2,311 rows
36_RevenueTransaction.csv: 15,203 rows
34_EncounterService.csv: 14,913 rows
OP visit minutes: 149 rows (3 s)
ER stay minutes: 1053 rows (6 s)
OR / anaesthesia minutes: 8 rows (3 s)
IP bed-days: 674 rows (6 s)
Floor consumption qty: 1649 rows (1 s)
IP consumed items qty: 0 rows (1 s)
OP meds: 5 prescription(s) had only pack/course qty (DispensedQuantity/Quantity/Qty) and were not written as DOSE.
OP dispensed meds qty: 4679 rows (1 s)
ActivityTransaction 8212 measured rows (VIDA-HIS). UnitPrice / invoice price is not written.
35_ActivityTransaction.csv: 8,212 rows
Consumption: 163 admissions, 3712 appointments, 351 ER assessments in scope (9 s)
Consumption: 22580 counted invoice lines on the pack's encounters to link items to (11 s)
Floor consumption items: 7513 rows (7 s)
IP consumed items: 0 rows (1 s)
Implants skipped: Error converting data type varchar to bigint.
OP dispensed medicine: 5105 rows (6 s)
Billed medicine lines: 364 rows
Consumption: IP medicine is the billed quantity until the pharmacy dispense feed is joined. Billed consumable charge codes without an issue row are not written yet (category list to be confirmed).
39_ConsumptionItem.csv: 12,982 rows
OR staff minutes: 4 rows (1 s)
OP doctor minutes: 149 rows (1 s)
ER doctor / nurse minutes: 702 rows (2 s)
Ward nursing (standard): 336 rows (1 s)
StaffTime: ward nursing is patient-days × 260 min (STANDARD) until nursing supplies a standard per ward. ER minutes are the patient's stay.
40_StaffTime.csv: 1,191 rows
Facts extract finished

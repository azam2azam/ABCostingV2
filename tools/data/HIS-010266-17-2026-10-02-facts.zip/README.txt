﻿HIS extract (HISGENX)
Pack: facts
HIS SetupID: 010266
HIS ProjectID: 17
Period: 2026-10-02 .. 2026-10-02 inclusive
Extracted (UTC): 2026-11-18 15:20:22Z

Identity is SetupID + ProjectID (every CSV + zip name). Do not treat the zip
filename as a VERITA hospital. Inner CSV names stay NN_Table.csv.

Facts are one zip per day. Utilization is raw/measured — not invented Activity×Resource:
39_ConsumptionItem.csv (item quantities), 40_StaffTime.csv (OR/OP/ER staff minutes),
41_EncounterTransfer.csv (INP_Transfer timing as stored). 35_ActivityTransaction.csv
is omitted (no ACT-/RES- invent from HIS clocks). Invoice price is not cost. Each day
carries every invoice (incl. claimed/settled/rejected), item and minute of the
encounters admitted or invoiced that day — encounter-driven, not only rows dated in
the window (ER appointment links folded into the day's appointment set so claims
still follow). Rows are keyed by sourceRef. Import remaps SetupID-ProjectID onto VERITA.

00_manifest.csv: 1 rows
Facts 2026-10-02 .. 2026-10-03 (SQL end exclusive)
32_Patient.csv: 825 rows
Drg on IP: 10047 admissions (0 from INP_AdmissionDRGList).
Drg on OP: 0 appointments from HIS_ApprovalDRG.
ER links by InvoiceNo: 46027.
ER links by AppointmentID: 50490.
ER encounters: 417 linked by AppointmentID, 0 linked by InvoiceNo, 0 with no appointment. 0 AppointmentID values had no appointment for the same patient; 0 assessments shared an appointment with another.
33_Encounter.csv: 908 rows
Billing: 41 admissions, 867 appointments, 403 ER assessments in scope (7 s)
Billing encounter-driven: 8259 revenue lines (4612 with InvoiceDate outside the pack window — kept for claims). No encounter: 0.
RefundTransaction 36 lines (encounter-driven + in-window): 0 on cancelled refunds, 4 with no encounter. Not written as revenue.
37_RefundTransaction.csv: 36 rows
InvoicePackageItem 1967 lines (encounter-driven; 1962 with InvoiceDate outside the pack window). No encounter: 0. Not written as services or revenue.
38_InvoicePackageItem.csv: 1,967 rows
36_RevenueTransaction.csv: 8,259 rows
34_EncounterService.csv: 8,045 rows
Claims: claim, settlement and NPHIES lines not extracted (pass --claims). Claimed is hisIsClaimed on 36_RevenueTransaction (HIS_InvoiceMain.IsClaimed).
Consumption: 41 admissions, 867 appointments, 403 ER assessments in scope (7 s)
Consumption: 7212 counted invoice lines on the pack's encounters to link items to (0 s)
Consumption: 886 item names from PHARMAKON.dbo.PHR_Item (18 s)
Floor consumption items: 1862 rows (5 s)
IP consumed items: 0 rows (1 s)
IP consumable log rows: 0 rows (0 s)
Implants: 25 rows (10 s)
OP dispensed medicine: 1656 rows (6 s)
IP medicine orders: 0 rows (0 s)
Billed medicine lines: 206 rows
Billed oracle-linked consumable lines: 0 rows
Consumption: as-received HIS fields kept (TransType, prices, order keys). Returns not netted — Verita can net later. No ACT/RES invent.
39_ConsumptionItem.csv: 3,749 rows
OR staff minutes: 0 rows (1 s)
Implant scrub / circulating nurses: 0 rows (1 s)
Operative report nurses / techs: 0 rows (0 s)
Nursing procedure note clocks: 0 rows (0 s)
OP doctor minutes: 39 rows (0 s)
ER doctor / nurse minutes: 806 rows (1 s)
StaffTime: measured HIS clocks + named staff ids as received. Ward nursing standards are not invented — see 41_EncounterTransfer.csv.
40_StaffTime.csv: 845 rows
IP bed/ward transfers: 86 rows (1 s)
EncounterTransfer: INP_Transfer fields as received (timing, room/bed, doctors, status) — no minutes or patient-day conversion.
41_EncounterTransfer.csv: 86 rows
Facts extract finished (no invented ActivityTransaction ACT/RES volumes)

﻿HIS extract (HISGENX)
Pack: facts
HIS SetupID: 010266
HIS ProjectID: 17
Period: 2026-11-03 .. 2026-11-03 inclusive
Extracted (UTC): 2026-11-17 12:28:04Z

Identity is SetupID + ProjectID (every CSV + zip name). Do not treat the zip
filename as a VERITA hospital. Inner CSV names stay NN_Table.csv.

Facts are one zip per day. They include 35_ActivityTransaction.csv from measured HIS
clocks and quantities, 39_ConsumptionItem.csv (consumables, implants, medicine by item)
and 40_StaffTime.csv (OR team, OP/ER doctor, ward nursing minutes). Quantities only:
invoice price is not cost. Each day carries every item and minute of the encounters
admitted or invoiced that day; rows are keyed by sourceRef, so re-sent rows update.
Import remaps SetupID-ProjectID codes onto the VERITA hospital you pick.

00_manifest.csv: 1 rows
Facts 2026-11-03 .. 2026-11-04 (SQL end exclusive)
32_Patient.csv: 3,376 rows
Drg on IP: 9929 admissions (0 from INP_AdmissionDRGList).
Drg on OP: 0 appointments from HIS_ApprovalDRG.
ER links by InvoiceNo: 36297.
ER links by AppointmentID: 39773.
ER encounters: 384 linked by AppointmentID, 0 linked by InvoiceNo, 0 with no appointment. 0 AppointmentID values had no appointment for the same patient; 0 assessments shared an appointment with another.
33_Encounter.csv: 3,952 rows
Invoice lines with no appointment, admission or ER assessment, not loaded: 0.
RefundTransaction 75 lines: 0 on cancelled refunds, 22 with no encounter. Not written as revenue.
37_RefundTransaction.csv: 75 rows
InvoicePackageItem 2785 lines: 0 with no encounter. Not written as services or revenue.
38_InvoicePackageItem.csv: 2,785 rows
36_RevenueTransaction.csv: 16,731 rows
34_EncounterService.csv: 16,450 rows
OP visit minutes: 174 rows (3 s)
ER stay minutes: 1101 rows (5 s)
OR / anaesthesia minutes: 6 rows (5 s)
IP bed-days: 688 rows (3 s)
Floor consumption qty: 1408 rows (1 s)
IP consumed items qty: 0 rows (0 s)
OP meds: 1 prescription(s) had only pack/course qty (DispensedQuantity/Quantity/Qty) and were not written as DOSE.
OP dispensed meds qty: 4918 rows (2 s)
ActivityTransaction 8295 measured rows (VIDA-HIS). UnitPrice / invoice price is not written.
35_ActivityTransaction.csv: 8,295 rows
Consumption: 170 admissions, 3778 appointments, 367 ER assessments in scope (7 s)
Consumption: 26306 counted invoice lines on the pack's encounters to link items to (7 s)
Floor consumption items: 10217 rows (4 s)
IP consumed items: 0 rows (1 s)
Implants skipped: Error converting data type varchar to bigint.
OP dispensed medicine: 5258 rows (5 s)
Billed medicine lines: 323 rows
Consumption: IP medicine is the billed quantity until the pharmacy dispense feed is joined. Billed consumable charge codes without an issue row are not written yet (category list to be confirmed).
39_ConsumptionItem.csv: 15,798 rows
OR staff minutes: 3 rows (0 s)
OP doctor minutes: 174 rows (0 s)
ER doctor / nurse minutes: 734 rows (1 s)
Ward nursing (standard): 341 rows (0 s)
StaffTime: ward nursing is patient-days × 260 min (STANDARD) until nursing supplies a standard per ward. ER minutes are the patient's stay.
40_StaffTime.csv: 1,252 rows
Facts extract finished

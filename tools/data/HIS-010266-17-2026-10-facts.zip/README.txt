﻿HIS extract (HISGENX)
Pack: facts
HIS SetupID: 010266
HIS ProjectID: 17
Period: 2026-10-01 .. 2026-10-31 inclusive
Extracted (UTC): 2026-11-03 13:11:05Z

Identity is SetupID + ProjectID (every CSV + zip name). Do not treat the zip
filename as a VERITA hospital. Inner CSV names stay NN_Table.csv.

Facts include 35_ActivityTransaction.csv from measured HIS clocks and quantities
(visit/ER/OR times, bed-days, floor stock, dispensed qty). Invoice price is not cost.
Import remaps SetupID-ProjectID codes onto the VERITA hospital you pick.

00_manifest.csv: 1 rows
Facts 2026-10-01 .. 2026-11-01 (SQL end exclusive)
32_Patient.csv: 50,000 rows
32_Patient_p2.csv: 6,587 rows
32_Patient.csv: 56,587 rows in 2 files
Drg on IP: 9159 admissions (0 from INP_AdmissionDRGList).
Drg on OP: 0 appointments from HIS_ApprovalDRG.
ER links by InvoiceNo: 41656.
ER links by AppointmentID: 45672.
ER encounters: 12007 linked by AppointmentID, 0 linked by InvoiceNo, 1 with no appointment. 1 AppointmentID values had no appointment for the same patient; 10 assessments shared an appointment with another.
33_Encounter.csv: 50,000 rows
33_Encounter_p2.csv: 50,000 rows
33_Encounter_p3.csv: 50,000 rows
33_Encounter_p4.csv: 38,328 rows
33_Encounter.csv: 188,328 rows in 4 files
36_RevenueTransaction.csv: 50,000 rows
34_EncounterService.csv: 50,000 rows
36_RevenueTransaction_p2.csv: 50,000 rows
34_EncounterService_p2.csv: 50,000 rows
36_RevenueTransaction_p3.csv: 50,000 rows
34_EncounterService_p3.csv: 50,000 rows
36_RevenueTransaction_p4.csv: 50,000 rows
34_EncounterService_p4.csv: 50,000 rows
36_RevenueTransaction_p5.csv: 50,000 rows
34_EncounterService_p5.csv: 50,000 rows
36_RevenueTransaction_p6.csv: 50,000 rows
34_EncounterService_p6.csv: 50,000 rows
36_RevenueTransaction_p7.csv: 50,000 rows
34_EncounterService_p7.csv: 50,000 rows
36_RevenueTransaction_p8.csv: 50,000 rows
34_EncounterService_p8.csv: 50,000 rows
36_RevenueTransaction_p9.csv: 50,000 rows
34_EncounterService_p9.csv: 50,000 rows
Invoice lines with no appointment, admission or ER assessment, not loaded: 0.
RefundTransaction 2696 lines: 0 on cancelled refunds, 476 with no encounter. Not written as revenue.
37_RefundTransaction.csv: 2,696 rows
38_InvoicePackageItem.csv: 50,000 rows
InvoicePackageItem 86741 lines: 0 with no encounter. Not written as services or revenue.
38_InvoicePackageItem_p2.csv: 36,741 rows
38_InvoicePackageItem.csv: 86,741 rows in 2 files
36_RevenueTransaction_p10.csv: 36,209 rows
36_RevenueTransaction.csv: 486,209 rows in 10 files
34_EncounterService_p10.csv: 27,860 rows
34_EncounterService.csv: 477,860 rows in 10 files
OP visit minutes: 3384 rows
ER stay minutes: 35799 rows
OR / anaesthesia minutes: 26 rows
35_ActivityTransaction.csv: 50,000 rows
IP bed-days: 11342 rows
35_ActivityTransaction_p2.csv: 50,000 rows
Floor consumption qty: 81790 rows
IP consumed items qty: 0 rows
35_ActivityTransaction_p3.csv: 50,000 rows
35_ActivityTransaction_p4.csv: 50,000 rows
35_ActivityTransaction_p5.csv: 50,000 rows
OP meds: 62 prescription(s) had only pack/course qty (DispensedQuantity/Quantity/Qty) and were not written as DOSE.
OP dispensed meds qty: 131865 rows
ActivityTransaction 264206 measured rows (VIDA-HIS). UnitPrice / invoice price is not written.
35_ActivityTransaction_p6.csv: 14,206 rows
35_ActivityTransaction.csv: 264,206 rows in 6 files
Facts extract finished

﻿HIS extract (HISGENX)
Pack: facts
HIS SetupID: 010266
HIS ProjectID: 17
Period: 2026-10-01 .. 2026-10-10 inclusive
Extracted (UTC): 2026-11-10 11:45:37Z

Identity is SetupID + ProjectID (every CSV + zip name). Do not treat the zip
filename as a VERITA hospital. Inner CSV names stay NN_Table.csv.

Facts include 35_ActivityTransaction.csv from measured HIS clocks and quantities
(visit/ER/OR times, bed-days, floor stock, dispensed qty). Invoice price is not cost.
Import remaps SetupID-ProjectID codes onto the VERITA hospital you pick.

00_manifest.csv: 1 rows
Facts 2026-10-01 .. 2026-10-11 (SQL end exclusive)
32_Patient.csv: 20,080 rows
Drg on IP: 9523 admissions (0 from INP_AdmissionDRGList).
Drg on OP: 0 appointments from HIS_ApprovalDRG.
ER links by InvoiceNo: 43908.
ER links by AppointmentID: 48138.
ER encounters: 4335 linked by AppointmentID, 0 linked by InvoiceNo, 0 with no appointment. 0 AppointmentID values had no appointment for the same patient; 6 assessments shared an appointment with another.
33_Encounter.csv: 30,930 rows
36_RevenueTransaction.csv: 50,000 rows
34_EncounterService.csv: 50,000 rows
36_RevenueTransaction_p2.csv: 50,000 rows
34_EncounterService_p2.csv: 50,000 rows
Invoice lines with no appointment, admission or ER assessment, not loaded: 0.
RefundTransaction 947 lines: 0 on cancelled refunds, 127 with no encounter. Not written as revenue.
37_RefundTransaction.csv: 947 rows
InvoicePackageItem 20948 lines: 0 with no encounter. Not written as services or revenue.
38_InvoicePackageItem.csv: 20,948 rows
36_RevenueTransaction_p3.csv: 29,442 rows
36_RevenueTransaction.csv: 129,442 rows in 3 files
34_EncounterService_p3.csv: 26,916 rows
34_EncounterService.csv: 126,916 rows in 3 files
OP visit minutes: 1024 rows
ER stay minutes: 12870 rows
OR / anaesthesia minutes: 8 rows
IP bed-days: 4186 rows
Floor consumption qty: 20554 rows
IP consumed items qty: 0 rows
35_ActivityTransaction.csv: 50,000 rows
OP meds: 22 prescription(s) had only pack/course qty (DispensedQuantity/Quantity/Qty) and were not written as DOSE.
OP dispensed meds qty: 43461 rows
ActivityTransaction 82103 measured rows (VIDA-HIS). UnitPrice / invoice price is not written.
35_ActivityTransaction_p2.csv: 32,103 rows
35_ActivityTransaction.csv: 82,103 rows in 2 files
Facts extract finished

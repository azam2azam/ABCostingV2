﻿HIS extract (HISGENX)
Pack: facts
HIS SetupID: 010266
HIS ProjectID: 17
Period: 2026-10-01 .. 2026-10-28 inclusive
Extracted (UTC): 2026-10-28 14:39:04Z
Server: SWD-AGLSNR

Identity is SetupID + ProjectID (every CSV + zip name). Do not treat the zip
filename as a VERITA hospital. Inner CSV names stay NN_Table.csv.

Facts include 35_ActivityTransaction.csv from measured HIS clocks and quantities
(visit/ER/OR times, bed-days, floor stock, dispensed qty). Invoice price is not cost.
Import remaps SetupID-ProjectID codes onto the VERITA hospital you pick.

00_manifest.csv: 1 rows
Facts 2026-10-01 .. 2026-10-29 (SQL end exclusive)
32_Patient.csv: 50,000 rows
32_Patient_p2.csv: 3,155 rows
32_Patient.csv: 53,155 rows in 2 files
33_Encounter.csv: 50,000 rows
33_Encounter_p2.csv: 50,000 rows
33_Encounter_p3.csv: 50,000 rows
33_Encounter_p4.csv: 33,387 rows
33_Encounter.csv: 183,387 rows in 4 files
36_RevenueTransaction.csv: 50,000 rows
34_EncounterService.csv: 50,000 rows
36_RevenueTransaction_p2.csv: 50,000 rows
34_EncounterService_p2.csv: 50,000 rows
36_RevenueTransaction_p3.csv: 50,000 rows
34_EncounterService_p3.csv: 50,000 rows
36_RevenueTransaction_p4.csv: 50,000 rows
34_EncounterService_p4.csv: 50,000 rows
36_RevenueTransaction_p5.csv: 50,000 rows
34_EncounterService_p5.csv: 50,000 rows
36_RevenueTransaction_p6.csv: 50,000 rows
34_EncounterService_p6.csv: 50,000 rows
36_RevenueTransaction_p7.csv: 50,000 rows
34_EncounterService_p7.csv: 50,000 rows
36_RevenueTransaction_p8.csv: 50,000 rows
34_EncounterService_p8.csv: 50,000 rows
36_RevenueTransaction_p9.csv: 33,546 rows
36_RevenueTransaction.csv: 433,546 rows in 9 files
34_EncounterService_p9.csv: 23,981 rows
34_EncounterService.csv: 423,981 rows in 9 files
OP visit minutes: 3069 rows
ER stay minutes: 32325 rows
OR / anaesthesia minutes: 26 rows
IP bed-days: 10024 rows
35_ActivityTransaction.csv: 50,000 rows
35_ActivityTransaction_p2.csv: 50,000 rows
Floor consumption qty: 74477 rows
IP consumed items qty: 0 rows
35_ActivityTransaction_p3.csv: 50,000 rows
35_ActivityTransaction_p4.csv: 50,000 rows
OP dispensed meds qty: 121143 rows
ActivityTransaction 241064 measured rows (VIDA-HIS). UnitPrice / invoice price is not written.
35_ActivityTransaction_p5.csv: 41,064 rows
35_ActivityTransaction.csv: 241,064 rows in 5 files
Facts extract finished

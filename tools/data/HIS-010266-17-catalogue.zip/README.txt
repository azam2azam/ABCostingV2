﻿HIS extract (HISGENX)
Pack: catalogue
HIS SetupID: 010266
HIS ProjectID: 17
Period: n/a
Extracted (UTC): 2026-11-03 13:00:07Z

Identity is SetupID + ProjectID (every CSV + zip name). Do not treat the zip
filename as a VERITA hospital. Inner CSV names stay NN_Table.csv.

Facts include 35_ActivityTransaction.csv from measured HIS clocks and quantities
(visit/ER/OR times, bed-days, floor stock, dispensed qty). Invoice price is not cost.
Import remaps SetupID-ProjectID codes onto the VERITA hospital you pick.

00_manifest.csv: 1 rows
01_Hospital.csv: 1 rows
02_Facility.csv: 2 rows
03_ServiceLine.csv: 48 rows
04_Department.csv: 356 rows
CostCenter: 2 Oracle codes appear on invoices but not in HIS_CostCenterSetup and were added.
CostCenter: HIS_CostCenterSetup + invoice CostCenterID only, all on Unmapped. No dummy CC-CLN/NS/OT/LAB.
05_CostCenter.csv: 215 rows
11_Resource.csv: 16 rows
14_Provider.csv: 2,081 rows
18_Procedure.csv: 24,113 rows
19_ProcedureRate.csv: 24,113 rows
25_PackageComponent.csv: 35,641 rows
24_Package.csv: 3,775 rows
Drg: 523 codes (0 from HIS_DRGSpecification).
26_Drg.csv: 523 rows
27_Payer.csv: 50,000 rows
27_Payer_p2.csv: 50,000 rows
27_Payer_p3.csv: 5,298 rows
27_Payer.csv: 105,298 rows in 3 files
Catalogue extract finished 2026-11-03 00:00:00Z

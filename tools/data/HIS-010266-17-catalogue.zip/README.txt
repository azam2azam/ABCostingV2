﻿HIS extract (HISGENX)
Pack: catalogue
HIS SetupID: 010266
HIS ProjectID: 17
Period: n/a
Extracted (UTC): 2026-11-17 11:55:08Z

Identity is SetupID + ProjectID (every CSV + zip name). Do not treat the zip
filename as a VERITA hospital. Inner CSV names stay NN_Table.csv.

Facts are one zip per day. They include 35_ActivityTransaction.csv from measured HIS
clocks and quantities, 39_ConsumptionItem.csv (consumables, implants, medicine by item)
and 40_StaffTime.csv (OR team, OP/ER doctor, ward nursing minutes). Quantities only:
invoice price is not cost. Each day carries every item and minute of the encounters
admitted or invoiced that day; rows are keyed by sourceRef, so re-sent rows update.
Import remaps SetupID-ProjectID codes onto the VERITA hospital you pick.

00_manifest.csv: 1 rows
01_Hospital.csv: 1 rows
02_Facility.csv: 2 rows
03_ServiceLine.csv: 48 rows
04_Department.csv: 359 rows
CostCenter: 2 Oracle codes appear on invoices but not in HIS_CostCenterSetup and were added.
CostCenter → Department by billed: 39
CostCenter → Department by his-rule: 12
CostCenter → Department by name: 6
CostCenter → Department by sibling: 33
CostCenter → Department: 124 of 214 left on UNMAPPED.
05_CostCenter.csv: 215 rows
11_Resource.csv: 16 rows
15_ProviderClinic.csv: 5,584 rows
14_Provider.csv: 2,363 rows
18_Procedure.csv: 24,125 rows
19_ProcedureRate.csv: 24,125 rows
25_PackageComponent.csv: 35,678 rows
24_Package.csv: 3,783 rows
Drg: 535 codes (0 from HIS_DRGSpecification).
26_Drg.csv: 535 rows
27_Payer.csv: 50,000 rows
27_Payer_p2.csv: 50,000 rows
Payer: 105731 companies under a HIS_CompanyGroup, 0 with none.
27_Payer_p3.csv: 5,732 rows
27_Payer.csv: 105,732 rows in 3 files
Catalogue extract finished 2026-11-17 00:00:00Z

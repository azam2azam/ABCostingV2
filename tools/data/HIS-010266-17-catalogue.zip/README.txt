﻿HIS extract (HISGENX)
Pack: catalogue
HIS SetupID: 010266
HIS ProjectID: 17
Period: n/a
Extracted (UTC): 2026-10-28 14:37:02Z
Server: SWD-AGLSNR

Identity is SetupID + ProjectID (every CSV + zip name). Do not treat the zip
filename as a VERITA hospital. Inner CSV names stay NN_Table.csv.

Facts include 35_ActivityTransaction.csv from measured HIS clocks and quantities
(visit/ER/OR times, bed-days, floor stock, dispensed qty). Invoice price is not cost.
Import remaps SetupID-ProjectID codes onto the VERITA hospital you pick.

00_manifest.csv: 1 rows
01_Hospital.csv: 1 rows
02_Facility.csv: 2 rows
03_ServiceLine.csv: 48 rows
04_Department.csv: 283 rows
05_CostCenter.csv: 494 rows
11_Resource.csv: 16 rows
14_Provider.csv: 2,080 rows
18_Procedure.csv: 24,084 rows
19_ProcedureRate.csv: 24,084 rows
25_PackageComponent.csv: 50,000 rows
25_PackageComponent_p2.csv: 12,830 rows
25_PackageComponent.csv: 62,830 rows in 2 files
24_Package.csv: 3,766 rows
26_Drg.csv: 0 rows
27_Payer.csv: 50,000 rows
27_Payer_p2.csv: 50,000 rows
27_Payer_p3.csv: 5,067 rows
27_Payer.csv: 105,067 rows in 3 files
Catalogue extract finished 2026-10-28 00:00:00Z

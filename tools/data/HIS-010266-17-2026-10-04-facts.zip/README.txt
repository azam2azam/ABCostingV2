﻿HIS extract (HISGENX)
Pack: facts
HIS SetupID: 010266
HIS ProjectID: 17
Period: 2026-10-04 .. 2026-10-04 inclusive
Extracted (UTC): 2026-11-18 14:47:56Z

Identity is SetupID + ProjectID (every CSV + zip name). Do not treat the zip
filename as a VERITA hospital. Inner CSV names stay NN_Table.csv.

Facts are one zip per day. Utilization is raw/measured — not invented Activity×Resource:
39_ConsumptionItem.csv (item quantities), 40_StaffTime.csv (OR/OP/ER staff minutes),
41_EncounterTransfer.csv (INP_Transfer timing as stored). 35_ActivityTransaction.csv
is omitted (no ACT-/RES- invent from HIS clocks). Invoice price is not cost. Each day
carries every invoice (incl. claimed/settled/rejected), item and minute of the
encounters admitted or invoiced that day — encounter-driven, not only rows dated in
the window (ER appointment links folded into the day's appointment set so claims
still follow). Rows are keyed by sourceRef. Import remaps SetupID-ProjectID onto VERITA.

00_manifest.csv: 1 rows
Facts 2026-10-04 .. 2026-10-05 (SQL end exclusive)
32_Patient.csv: 3,834 rows
Drg on IP: 10044 admissions (0 from INP_AdmissionDRGList).
Drg on OP: 0 appointments from HIS_ApprovalDRG.
ER links by InvoiceNo: 45472.
ER links by AppointmentID: 49873.
ER encounters: 510 linked by AppointmentID, 0 linked by InvoiceNo, 0 with no appointment. 0 AppointmentID values had no appointment for the same patient; 4 assessments shared an appointment with another.
Encounter: 1 skipped because the patient is not in 32_Patient.csv, with all their rows: OP 1 (patient 1979510).
33_Encounter.csv: 4,478 rows
Billing: 266 admissions, 4213 appointments, 486 ER assessments in scope (8 s)
Billing encounter-driven: 35964 revenue lines (16559 with InvoiceDate outside the pack window — kept for claims). No encounter: 0.
RefundTransaction 266 lines (encounter-driven + in-window): 0 on cancelled refunds, 12 with no encounter. Not written as revenue.
37_RefundTransaction.csv: 266 rows
InvoicePackageItem 10038 lines (encounter-driven; 5759 with InvoiceDate outside the pack window). No encounter: 0. Not written as services or revenue.
38_InvoicePackageItem.csv: 10,038 rows
36_RevenueTransaction.csv: 35,964 rows
34_EncounterService.csv: 35,444 rows
Claims: 9030 pack invoices to read claims, settlements and NPHIES responses for (any date, as of now).
42_ClaimLine.csv: 0 rows
Claim lines skipped: Invalid column name 'NPHIESClaimRemarks'.
Invalid column name 'NPHIESTaxAmount'.
Invalid column name 'NPHIESClaimUpdateDate'.
Invalid column name 'NPHIESClaimReference'.
SettlementLine: 0 HIS_SettlementProcedure lines (paid / rejected, with settlement invoice + receipt header) on the pack invoices.
43_SettlementLine.csv: 0 rows
NphiesClaimLine: 0 HIS_NPHIESClaimProcedure_Log lines (submitted / approved / reason, with rejection remarks) on the pack invoices.
44_NphiesClaimLine.csv: 0 rows
NphiesPayment: 0 HIS_NPHIESPaymentReconciliation lines naming a pack claim (identifier match — check against HIS if 0).
45_NphiesPayment.csv: 0 rows
Consumption: 266 admissions, 4213 appointments, 486 ER assessments in scope (7 s)
Consumption: 28967 counted invoice lines on the pack's encounters to link items to (6 s)
Consumption: 2041 item names from PHARMAKON.dbo.PHR_Item (12 s)
Floor consumption items: 12023 rows (4 s)
IP consumed items: 0 rows (1 s)
IP consumable log rows: 0 rows (0 s)
Implants skipped: Error converting data type varchar to bigint.
OP dispensed medicine: 6080 rows (5 s)
IP medicine orders: 0 rows (0 s)
Billed medicine lines: 470 rows
Billed oracle-linked consumable lines: 7 rows
Consumption: as-received HIS fields kept (TransType, prices, order keys). Returns not netted — Verita can net later. No ACT/RES invent.
39_ConsumptionItem.csv: 18,580 rows
OR staff minutes: 1 rows (0 s)
Implant scrub / circulating nurses: 2 rows (0 s)
Operative report nurses / techs: 0 rows (0 s)
Nursing procedure note clocks: 0 rows (0 s)
OP doctor minutes: 119 rows (0 s)
ER doctor / nurse minutes: 972 rows (1 s)
StaffTime: measured HIS clocks + named staff ids as received. Ward nursing standards are not invented — see 41_EncounterTransfer.csv.
40_StaffTime.csv: 1,094 rows
IP bed/ward transfers: 581 rows (1 s)
EncounterTransfer: INP_Transfer fields as received (timing, room/bed, doctors, status) — no minutes or patient-day conversion.
41_EncounterTransfer.csv: 581 rows
Skipped encounters (no patient): rows left out — 34_EncounterService / 36_RevenueTransaction 151.
Facts extract finished (no invented ActivityTransaction ACT/RES volumes)

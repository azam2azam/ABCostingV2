﻿VERITA HIS extract
Pack: catalogue
Hospital: RYN-UAT
HIS SetupID: 010266
HIS ProjectID: 15
Period: n/a
Extracted (UTC): 2026-10-27 12:58:15Z
Server: RAY-VIDA-UAT

Import on Data import. Use a user whose hospitalScope includes RYN-UAT
(or *). Shared tables (Payer, Drg, ServiceLine) need hospitalScope = *.
Validate (dry run) before Import.

01_Hospital.csv: 1 rows
02_Facility.csv: 6 rows
03_ServiceLine.csv: 47 rows
04_Department.csv: 207 rows
05_CostCenter.csv: 418 rows
11_Resource.csv: 1 rows
14_Provider.csv: 1,625 rows
18_Procedure.csv: 21,209 rows
19_ProcedureRate.csv: 21,209 rows
25_PackageComponent.csv: 47,359 rows
24_Package.csv: 2,771 rows
26_Drg.csv: 301 rows
27_Payer.csv: 32,861 rows
Catalogue extract finished 2026-10-27 00:00:00Z

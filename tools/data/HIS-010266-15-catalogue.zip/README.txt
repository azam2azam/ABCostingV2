﻿HIS extract (HISGENX)
Pack: catalogue
HIS SetupID: 010266
HIS ProjectID: 15
Period: n/a
Extracted (UTC): 2026-10-28 08:56:46Z
Server: RAY-VIDA-UAT

Identity is SetupID + ProjectID (every CSV + zip name). Do not treat the zip
filename as a VERITA hospital. Inner CSV names stay NN_Table.csv.

These packs are not yet importable into current VERITA Data import (extra
setupId/projectId columns + 00_manifest.csv). Copy the zips back for validation
before VERITA import is updated.

00_manifest.csv: 1 rows
01_Hospital.csv: 1 rows
02_Facility.csv: 6 rows
03_ServiceLine.csv: 47 rows
04_Department.csv: 207 rows
05_CostCenter.csv: 418 rows
11_Resource.csv: 16 rows
14_Provider.csv: 1,625 rows
18_Procedure.csv: 21,209 rows
19_ProcedureRate.csv: 21,209 rows
25_PackageComponent.csv: 47,359 rows
24_Package.csv: 2,771 rows
26_Drg.csv: 301 rows
27_Payer.csv: 32,861 rows
Catalogue extract finished 2026-10-28 00:00:00Z

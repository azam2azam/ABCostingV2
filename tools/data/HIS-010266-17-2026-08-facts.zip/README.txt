﻿HIS extract (HISGENX)
Pack: facts
HIS SetupID: 010266
HIS ProjectID: 17
Period: 2026-08-20 .. 2026-08-31 inclusive
Extracted (UTC): 2026-11-03 13:01:59Z

Identity is SetupID + ProjectID (every CSV + zip name). Do not treat the zip
filename as a VERITA hospital. Inner CSV names stay NN_Table.csv.

Facts include 35_ActivityTransaction.csv from measured HIS clocks and quantities
(visit/ER/OR times, bed-days, floor stock, dispensed qty). Invoice price is not cost.
Import remaps SetupID-ProjectID codes onto the VERITA hospital you pick.

00_manifest.csv: 1 rows
Facts 2026-08-20 .. 2026-09-01 (SQL end exclusive)
32_Patient.csv: 30,260 rows
Drg on IP: 9156 admissions (0 from INP_AdmissionDRGList).
Drg on OP: 0 appointments from HIS_ApprovalDRG.
ER links by InvoiceNo: 54427.
ER links by AppointmentID: 59689.
ER encounters: 4170 linked by AppointmentID, 0 linked by InvoiceNo, 0 with no appointment. 0 AppointmentID values had no appointment for the same patient; 9 assessments shared an appointment with another.
33_Encounter.csv: 50,000 rows
33_Encounter_p2.csv: 23,225 rows
33_Encounter.csv: 73,225 rows in 2 files
36_RevenueTransaction.csv: 50,000 rows
34_EncounterService.csv: 50,000 rows
36_RevenueTransaction_p2.csv: 50,000 rows
34_EncounterService_p2.csv: 50,000 rows
36_RevenueTransaction_p3.csv: 50,000 rows
34_EncounterService_p3.csv: 50,000 rows
36_RevenueTransaction_p4.csv: 50,000 rows
34_EncounterService_p4.csv: 50,000 rows
Invoice lines with no appointment, admission or ER assessment, not loaded: 0.
RefundTransaction 910 lines: 0 on cancelled refunds, 185 with no encounter. Not written as revenue.
37_RefundTransaction.csv: 910 rows
InvoicePackageItem 35414 lines: 0 with no encounter. Not written as services or revenue.
38_InvoicePackageItem.csv: 35,414 rows
36_RevenueTransaction_p5.csv: 12,211 rows
36_RevenueTransaction.csv: 212,211 rows in 5 files
34_EncounterService_p5.csv: 8,893 rows
34_EncounterService.csv: 208,893 rows in 5 files
OP visit minutes: 1360 rows
ER stay minutes: 12393 rows
OR / anaesthesia minutes: 12 rows
IP bed-days: 5308 rows
Floor consumption qty: 26796 rows
IP consumed items qty: 0 rows
35_ActivityTransaction.csv: 50,000 rows
OP meds: 13 prescription(s) had only pack/course qty (DispensedQuantity/Quantity/Qty) and were not written as DOSE.
OP dispensed meds qty: 48701 rows
ActivityTransaction 94570 measured rows (VIDA-HIS). UnitPrice / invoice price is not written.
35_ActivityTransaction_p2.csv: 44,570 rows
35_ActivityTransaction.csv: 94,570 rows in 2 files
Facts extract finished

﻿HIS extract (HISGENX)
Pack: facts
HIS SetupID: 010266
HIS ProjectID: 17
Period: 2026-08-01 .. 2026-08-10 inclusive
Extracted (UTC): 2026-11-10 11:41:20Z

Identity is SetupID + ProjectID (every CSV + zip name). Do not treat the zip
filename as a VERITA hospital. Inner CSV names stay NN_Table.csv.

Facts include 35_ActivityTransaction.csv from measured HIS clocks and quantities
(visit/ER/OR times, bed-days, floor stock, dispensed qty). Invoice price is not cost.
Import remaps SetupID-ProjectID codes onto the VERITA hospital you pick.

00_manifest.csv: 1 rows
Facts 2026-08-01 .. 2026-08-11 (SQL end exclusive)
32_Patient.csv: 18,967 rows
Drg on IP: 9522 admissions (0 from INP_AdmissionDRGList).
Drg on OP: 0 appointments from HIS_ApprovalDRG.
ER links by InvoiceNo: 63108.
ER links by AppointmentID: 69149.
ER encounters: 3371 linked by AppointmentID, 0 linked by InvoiceNo, 0 with no appointment. 0 AppointmentID values had no appointment for the same patient; 5 assessments shared an appointment with another.
33_Encounter.csv: 30,712 rows
36_RevenueTransaction.csv: 50,000 rows
34_EncounterService.csv: 50,000 rows
36_RevenueTransaction_p2.csv: 50,000 rows
34_EncounterService_p2.csv: 50,000 rows
Invoice lines with no appointment, admission or ER assessment, not loaded: 0.
RefundTransaction 1045 lines: 0 on cancelled refunds, 138 with no encounter. Not written as revenue.
37_RefundTransaction.csv: 1,045 rows
InvoicePackageItem 20875 lines: 0 with no encounter. Not written as services or revenue.
38_InvoicePackageItem.csv: 20,875 rows
36_RevenueTransaction_p3.csv: 33,096 rows
36_RevenueTransaction.csv: 133,096 rows in 3 files
34_EncounterService_p3.csv: 30,418 rows
34_EncounterService.csv: 130,418 rows in 3 files
OP visit minutes: 1146 rows
ER stay minutes: 9990 rows
OR / anaesthesia minutes: 4 rows
IP bed-days: 3916 rows
Floor consumption qty: 19574 rows
IP consumed items qty: 0 rows
35_ActivityTransaction.csv: 50,000 rows
OP meds: 12 prescription(s) had only pack/course qty (DispensedQuantity/Quantity/Qty) and were not written as DOSE.
OP dispensed meds qty: 40462 rows
ActivityTransaction 75092 measured rows (VIDA-HIS). UnitPrice / invoice price is not written.
35_ActivityTransaction_p2.csv: 25,092 rows
35_ActivityTransaction.csv: 75,092 rows in 2 files
Facts extract finished

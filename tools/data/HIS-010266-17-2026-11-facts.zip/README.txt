﻿HIS extract (HISGENX)
Pack: facts
HIS SetupID: 010266
HIS ProjectID: 17
Period: 2026-11-01 .. 2026-11-05 inclusive
Extracted (UTC): 2026-11-05 11:20:14Z

Identity is SetupID + ProjectID (every CSV + zip name). Do not treat the zip
filename as a VERITA hospital. Inner CSV names stay NN_Table.csv.

Facts include 35_ActivityTransaction.csv from measured HIS clocks and quantities
(visit/ER/OR times, bed-days, floor stock, dispensed qty). Invoice price is not cost.
Import remaps SetupID-ProjectID codes onto the VERITA hospital you pick.

00_manifest.csv: 1 rows
Facts 2026-11-01 .. 2026-11-06 (SQL end exclusive)
32_Patient.csv: 11,579 rows
Drg on IP: 9299 admissions (0 from INP_AdmissionDRGList).
Drg on OP: 0 appointments from HIS_ApprovalDRG.
ER links by InvoiceNo: 33249.
ER links by AppointmentID: 36399.
ER encounters: 1638 linked by AppointmentID, 0 linked by InvoiceNo, 0 with no appointment. 0 AppointmentID values had no appointment for the same patient; 2 assessments shared an appointment with another.
33_Encounter.csv: 16,303 rows
36_RevenueTransaction.csv: 50,000 rows
34_EncounterService.csv: 50,000 rows
Invoice lines with no appointment, admission or ER assessment, not loaded: 0.
RefundTransaction 651 lines: 0 on cancelled refunds, 80 with no encounter. Not written as revenue.
37_RefundTransaction.csv: 651 rows
InvoicePackageItem 15472 lines: 0 with no encounter. Not written as services or revenue.
38_InvoicePackageItem.csv: 15,472 rows
36_RevenueTransaction_p2.csv: 26,135 rows
36_RevenueTransaction.csv: 76,135 rows in 2 files
34_EncounterService_p2.csv: 24,821 rows
34_EncounterService.csv: 74,821 rows in 2 files
OP visit minutes: 572 rows
ER stay minutes: 4701 rows
OR / anaesthesia minutes: 14 rows
IP bed-days: 2204 rows
Floor consumption qty: 10311 rows
IP consumed items qty: 0 rows
OP meds: 11 prescription(s) had only pack/course qty (DispensedQuantity/Quantity/Qty) and were not written as DOSE.
OP dispensed meds qty: 20495 rows
ActivityTransaction 38297 measured rows (VIDA-HIS). UnitPrice / invoice price is not written.
35_ActivityTransaction.csv: 38,297 rows
Facts extract finished

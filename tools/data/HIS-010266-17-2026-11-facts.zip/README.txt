﻿HIS extract (HISGENX)
Pack: facts
HIS SetupID: 010266
HIS ProjectID: 17
Period: 2026-11-01 .. 2026-11-10 inclusive
Extracted (UTC): 2026-11-10 11:47:09Z

Identity is SetupID + ProjectID (every CSV + zip name). Do not treat the zip
filename as a VERITA hospital. Inner CSV names stay NN_Table.csv.

Facts include 35_ActivityTransaction.csv from measured HIS clocks and quantities
(visit/ER/OR times, bed-days, floor stock, dispensed qty). Invoice price is not cost.
Import remaps SetupID-ProjectID codes onto the VERITA hospital you pick.

00_manifest.csv: 1 rows
Facts 2026-11-01 .. 2026-11-11 (SQL end exclusive)
32_Patient.csv: 19,538 rows
Drg on IP: 9523 admissions (0 from INP_AdmissionDRGList).
Drg on OP: 0 appointments from HIS_ApprovalDRG.
ER links by InvoiceNo: 34876.
ER links by AppointmentID: 38173.
ER encounters: 3419 linked by AppointmentID, 0 linked by InvoiceNo, 0 with no appointment. 0 AppointmentID values had no appointment for the same patient; 4 assessments shared an appointment with another.
33_Encounter.csv: 31,095 rows
36_RevenueTransaction.csv: 50,000 rows
34_EncounterService.csv: 50,000 rows
36_RevenueTransaction_p2.csv: 50,000 rows
34_EncounterService_p2.csv: 50,000 rows
36_RevenueTransaction_p3.csv: 50,000 rows
34_EncounterService_p3.csv: 50,000 rows
Invoice lines with no appointment, admission or ER assessment, not loaded: 0.
RefundTransaction 1023 lines: 0 on cancelled refunds, 168 with no encounter. Not written as revenue.
37_RefundTransaction.csv: 1,023 rows
InvoicePackageItem 29774 lines: 0 with no encounter. Not written as services or revenue.
38_InvoicePackageItem.csv: 29,774 rows
36_RevenueTransaction_p4.csv: 6,167 rows
36_RevenueTransaction.csv: 156,167 rows in 4 files
34_EncounterService_p4.csv: 3,407 rows
34_EncounterService.csv: 153,407 rows in 4 files
OP visit minutes: 1103 rows
ER stay minutes: 10047 rows
OR / anaesthesia minutes: 14 rows
IP bed-days: 3894 rows
Floor consumption qty: 22280 rows
IP consumed items qty: 0 rows
35_ActivityTransaction.csv: 50,000 rows
OP meds: 20 prescription(s) had only pack/course qty (DispensedQuantity/Quantity/Qty) and were not written as DOSE.
OP dispensed meds qty: 40249 rows
ActivityTransaction 77587 measured rows (VIDA-HIS). UnitPrice / invoice price is not written.
35_ActivityTransaction_p2.csv: 27,587 rows
35_ActivityTransaction.csv: 77,587 rows in 2 files
Facts extract finished

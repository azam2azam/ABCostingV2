﻿HIS extract (HISGENX)
Pack: facts
HIS SetupID: 010266
HIS ProjectID: 17
Period: 2026-11-01 .. 2026-11-03 inclusive
Extracted (UTC): 2026-11-03 13:16:48Z

Identity is SetupID + ProjectID (every CSV + zip name). Do not treat the zip
filename as a VERITA hospital. Inner CSV names stay NN_Table.csv.

Facts include 35_ActivityTransaction.csv from measured HIS clocks and quantities
(visit/ER/OR times, bed-days, floor stock, dispensed qty). Invoice price is not cost.
Import remaps SetupID-ProjectID codes onto the VERITA hospital you pick.

00_manifest.csv: 1 rows
Facts 2026-11-01 .. 2026-11-04 (SQL end exclusive)
32_Patient.csv: 11,077 rows
Drg on IP: 9161 admissions (0 from INP_AdmissionDRGList).
Drg on OP: 0 appointments from HIS_ApprovalDRG.
ER links by InvoiceNo: 32626.
ER links by AppointmentID: 35708.
ER encounters: 940 linked by AppointmentID, 0 linked by InvoiceNo, 0 with no appointment. 0 AppointmentID values had no appointment for the same patient; 2 assessments shared an appointment with another.
33_Encounter.csv: 20,031 rows
Invoice lines with no appointment, admission or ER assessment, not loaded: 0.
RefundTransaction 416 lines: 0 on cancelled refunds, 47 with no encounter. Not written as revenue.
37_RefundTransaction.csv: 416 rows
InvoicePackageItem 9629 lines: 0 with no encounter. Not written as services or revenue.
38_InvoicePackageItem.csv: 9,629 rows
36_RevenueTransaction.csv: 44,252 rows
34_EncounterService.csv: 43,507 rows
OP visit minutes: 334 rows
ER stay minutes: 2649 rows
OR / anaesthesia minutes: 10 rows
IP bed-days: 1418 rows
Floor consumption qty: 6816 rows
IP consumed items qty: 0 rows
OP meds: 6 prescription(s) had only pack/course qty (DispensedQuantity/Quantity/Qty) and were not written as DOSE.
OP dispensed meds qty: 11682 rows
ActivityTransaction 22909 measured rows (VIDA-HIS). UnitPrice / invoice price is not written.
35_ActivityTransaction.csv: 22,909 rows
Facts extract finished

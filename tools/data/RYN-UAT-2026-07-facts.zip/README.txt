﻿VERITA HIS extract
Pack: facts
Hospital: RYN-UAT
HIS SetupID: 010266
HIS ProjectID: 15
Period: 2026-07-01 .. 2026-08-01
Extracted (UTC): 2026-10-27 13:07:28Z
Server: RAY-VIDA-UAT

Import on Data import. Use a user whose hospitalScope includes RYN-UAT
(or *). Shared tables (Payer, Drg, ServiceLine) need hospitalScope = *.
Validate (dry run) before Import.

Facts 2026-07-01 .. 2026-08-01 (exclusive end)
32_Patient.csv: 159 rows
33_Encounter.csv: 295 rows
36_RevenueTransaction.csv: 545 rows
34_EncounterService.csv: 507 rows
Facts extract finished

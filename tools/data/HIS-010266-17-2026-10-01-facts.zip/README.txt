﻿HIS extract (HISGENX)
Pack: facts
HIS SetupID: 010266
HIS ProjectID: 17
Period: 2026-10-01 .. 2026-10-01 inclusive
Extracted (UTC): 2026-11-18 15:18:08Z

Identity is SetupID + ProjectID (every CSV + zip name). Do not treat the zip
filename as a VERITA hospital. Inner CSV names stay NN_Table.csv.

Facts are one zip per day. Utilization is raw/measured — not invented Activity×Resource:
39_ConsumptionItem.csv (item quantities), 40_StaffTime.csv (OR/OP/ER staff minutes),
41_EncounterTransfer.csv (INP_Transfer timing as stored). 35_ActivityTransaction.csv
is omitted (no ACT-/RES- invent from HIS clocks). Invoice price is not cost. Each day
carries every invoice (incl. claimed/settled/rejected), item and minute of the
encounters admitted or invoiced that day — encounter-driven, not only rows dated in
the window (ER appointment links folded into the day's appointment set so claims
still follow). Rows are keyed by sourceRef. Import remaps SetupID-ProjectID onto VERITA.

00_manifest.csv: 1 rows
Facts 2026-10-01 .. 2026-10-02 (SQL end exclusive)
32_Patient.csv: 2,600 rows
Drg on IP: 10047 admissions (0 from INP_AdmissionDRGList).
Drg on OP: 0 appointments from HIS_ApprovalDRG.
ER links by InvoiceNo: 46303.
ER links by AppointmentID: 50797.
ER encounters: 460 linked by AppointmentID, 0 linked by InvoiceNo, 0 with no appointment. 0 AppointmentID values had no appointment for the same patient; 2 assessments shared an appointment with another.
Encounter: 2 skipped because the patient is not in 32_Patient.csv, with all their rows: ER 37048024 (patient 6621716), OP 1 (patient 1979510).
33_Encounter.csv: 3,019 rows
Billing: 191 admissions, 2829 appointments, 427 ER assessments in scope (8 s)
Billing encounter-driven: 24102 revenue lines (12583 with InvoiceDate outside the pack window — kept for claims). No encounter: 0.
RefundTransaction 216 lines (encounter-driven + in-window): 0 on cancelled refunds, 16 with no encounter. Not written as revenue.
37_RefundTransaction.csv: 216 rows
InvoicePackageItem 7277 lines (encounter-driven; 5220 with InvoiceDate outside the pack window). No encounter: 0. Not written as services or revenue.
38_InvoicePackageItem.csv: 7,277 rows
36_RevenueTransaction.csv: 24,102 rows
34_EncounterService.csv: 23,728 rows
Claims: claim, settlement and NPHIES lines not extracted (pass --claims). Claimed is hisIsClaimed on 36_RevenueTransaction (HIS_InvoiceMain.IsClaimed).
Consumption: 191 admissions, 2829 appointments, 427 ER assessments in scope (8 s)
Consumption: 18771 counted invoice lines on the pack's encounters to link items to (5 s)
Consumption: 1715 item names from PHARMAKON.dbo.PHR_Item (14 s)
Floor consumption items: 6711 rows (7 s)
IP consumed items: 0 rows (0 s)
IP consumable log rows: 0 rows (1 s)
Implants: 27 rows (19 s)
OP dispensed medicine: 4071 rows (9 s)
IP medicine orders: 0 rows (0 s)
Billed medicine lines: 336 rows
Billed oracle-linked consumable lines: 1 rows
Consumption: as-received HIS fields kept (TransType, prices, order keys). Returns not netted — Verita can net later. No ACT/RES invent.
39_ConsumptionItem.csv: 11,146 rows
OR staff minutes: 2 rows (1 s)
Implant scrub / circulating nurses: 2 rows (0 s)
Operative report nurses / techs: 0 rows (0 s)
Nursing procedure note clocks: 0 rows (0 s)
OP doctor minutes: 66 rows (0 s)
ER doctor / nurse minutes: 854 rows (1 s)
StaffTime: measured HIS clocks + named staff ids as received. Ward nursing standards are not invented — see 41_EncounterTransfer.csv.
40_StaffTime.csv: 924 rows
IP bed/ward transfers: 420 rows (0 s)
EncounterTransfer: INP_Transfer fields as received (timing, room/bed, doctors, status) — no minutes or patient-day conversion.
41_EncounterTransfer.csv: 420 rows
Skipped encounters (no patient): rows left out — 34_EncounterService / 36_RevenueTransaction 151.
Facts extract finished (no invented ActivityTransaction ACT/RES volumes)

﻿VERITA HIS extract
Pack: facts
Hospital: RYN-UAT
HIS SetupID: 010266
HIS ProjectID: 15
Period: 2026-10-01 .. 2026-11-01
Extracted (UTC): 2026-10-27 13:08:03Z
Server: RAY-VIDA-UAT

Import on Data import. Use a user whose hospitalScope includes RYN-UAT
(or *). Shared tables (Payer, Drg, ServiceLine) need hospitalScope = *.
Validate (dry run) before Import.

Facts 2026-10-01 .. 2026-11-01 (exclusive end)
32_Patient.csv: 242 rows
33_Encounter.csv: 555 rows
36_RevenueTransaction.csv: 513 rows
34_EncounterService.csv: 507 rows
Facts extract finished

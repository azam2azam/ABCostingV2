﻿HIS extract (HISGENX)
Pack: facts
HIS SetupID: 010266
HIS ProjectID: 17
Period: 2026-07-01 .. 2026-07-10 inclusive
Extracted (UTC): 2026-11-10 11:39:35Z

Identity is SetupID + ProjectID (every CSV + zip name). Do not treat the zip
filename as a VERITA hospital. Inner CSV names stay NN_Table.csv.

Facts include 35_ActivityTransaction.csv from measured HIS clocks and quantities
(visit/ER/OR times, bed-days, floor stock, dispensed qty). Invoice price is not cost.
Import remaps SetupID-ProjectID codes onto the VERITA hospital you pick.

00_manifest.csv: 1 rows
Facts 2026-07-01 .. 2026-07-11 (SQL end exclusive)
32_Patient.csv: 17,639 rows
Drg on IP: 9522 admissions (0 from INP_AdmissionDRGList).
Drg on OP: 0 appointments from HIS_ApprovalDRG.
ER links by InvoiceNo: 63504.
ER links by AppointmentID: 69472.
ER encounters: 3145 linked by AppointmentID, 0 linked by InvoiceNo, 0 with no appointment. 0 AppointmentID values had no appointment for the same patient; 3 assessments shared an appointment with another.
33_Encounter.csv: 27,571 rows
36_RevenueTransaction.csv: 50,000 rows
34_EncounterService.csv: 50,000 rows
36_RevenueTransaction_p2.csv: 50,000 rows
34_EncounterService_p2.csv: 50,000 rows
Invoice lines with no appointment, admission or ER assessment, not loaded: 0.
RefundTransaction 1008 lines: 0 on cancelled refunds, 116 with no encounter. Not written as revenue.
37_RefundTransaction.csv: 1,008 rows
InvoicePackageItem 18322 lines: 0 with no encounter. Not written as services or revenue.
38_InvoicePackageItem.csv: 18,322 rows
36_RevenueTransaction_p3.csv: 15,575 rows
36_RevenueTransaction.csv: 115,575 rows in 3 files
34_EncounterService_p3.csv: 13,266 rows
34_EncounterService.csv: 113,266 rows in 3 files
OP visit minutes: 1209 rows
ER stay minutes: 9324 rows
OR / anaesthesia minutes: 0 rows
IP bed-days: 3820 rows
Floor consumption qty: 18056 rows
IP consumed items qty: 0 rows
35_ActivityTransaction.csv: 50,000 rows
OP meds: 7 prescription(s) had only pack/course qty (DispensedQuantity/Quantity/Qty) and were not written as DOSE.
OP dispensed meds qty: 35071 rows
ActivityTransaction 67480 measured rows (VIDA-HIS). UnitPrice / invoice price is not written.
35_ActivityTransaction_p2.csv: 17,480 rows
35_ActivityTransaction.csv: 67,480 rows in 2 files
Facts extract finished

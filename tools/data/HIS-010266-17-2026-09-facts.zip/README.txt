﻿HIS extract (HISGENX)
Pack: facts
HIS SetupID: 010266
HIS ProjectID: 17
Period: 2026-09-01 .. 2026-09-30 inclusive
Extracted (UTC): 2026-11-03 13:05:28Z

Identity is SetupID + ProjectID (every CSV + zip name). Do not treat the zip
filename as a VERITA hospital. Inner CSV names stay NN_Table.csv.

Facts include 35_ActivityTransaction.csv from measured HIS clocks and quantities
(visit/ER/OR times, bed-days, floor stock, dispensed qty). Invoice price is not cost.
Import remaps SetupID-ProjectID codes onto the VERITA hospital you pick.

00_manifest.csv: 1 rows
Facts 2026-09-01 .. 2026-10-01 (SQL end exclusive)
32_Patient.csv: 50,000 rows
32_Patient_p2.csv: 6,850 rows
32_Patient.csv: 56,850 rows in 2 files
Drg on IP: 9158 admissions (0 from INP_AdmissionDRGList).
Drg on OP: 0 appointments from HIS_ApprovalDRG.
ER links by InvoiceNo: 50619.
ER links by AppointmentID: 55475.
ER encounters: 12278 linked by AppointmentID, 0 linked by InvoiceNo, 0 with no appointment. 0 AppointmentID values had no appointment for the same patient; 10 assessments shared an appointment with another.
33_Encounter.csv: 50,000 rows
33_Encounter_p2.csv: 50,000 rows
33_Encounter_p3.csv: 50,000 rows
33_Encounter_p4.csv: 34,971 rows
33_Encounter.csv: 184,971 rows in 4 files
36_RevenueTransaction.csv: 50,000 rows
34_EncounterService.csv: 50,000 rows
36_RevenueTransaction_p2.csv: 50,000 rows
34_EncounterService_p2.csv: 50,000 rows
36_RevenueTransaction_p3.csv: 50,000 rows
34_EncounterService_p3.csv: 50,000 rows
36_RevenueTransaction_p4.csv: 50,000 rows
34_EncounterService_p4.csv: 50,000 rows
36_RevenueTransaction_p5.csv: 50,000 rows
34_EncounterService_p5.csv: 50,000 rows
36_RevenueTransaction_p6.csv: 50,000 rows
34_EncounterService_p6.csv: 50,000 rows
36_RevenueTransaction_p7.csv: 50,000 rows
34_EncounterService_p7.csv: 50,000 rows
36_RevenueTransaction_p8.csv: 50,000 rows
34_EncounterService_p8.csv: 50,000 rows
36_RevenueTransaction_p9.csv: 50,000 rows
34_EncounterService_p9.csv: 50,000 rows
Invoice lines with no appointment, admission or ER assessment, not loaded: 0.
RefundTransaction 2714 lines: 0 on cancelled refunds, 499 with no encounter. Not written as revenue.
37_RefundTransaction.csv: 2,714 rows
38_InvoicePackageItem.csv: 50,000 rows
InvoicePackageItem 78608 lines: 0 with no encounter. Not written as services or revenue.
38_InvoicePackageItem_p2.csv: 28,608 rows
38_InvoicePackageItem.csv: 78,608 rows in 2 files
36_RevenueTransaction_p10.csv: 11,219 rows
36_RevenueTransaction.csv: 461,219 rows in 10 files
34_EncounterService_p10.csv: 3,052 rows
34_EncounterService.csv: 453,052 rows in 10 files
OP visit minutes: 3436 rows
ER stay minutes: 36684 rows
OR / anaesthesia minutes: 44 rows
35_ActivityTransaction.csv: 50,000 rows
IP bed-days: 11142 rows
35_ActivityTransaction_p2.csv: 50,000 rows
Floor consumption qty: 85573 rows
IP consumed items qty: 0 rows
35_ActivityTransaction_p3.csv: 50,000 rows
35_ActivityTransaction_p4.csv: 50,000 rows
35_ActivityTransaction_p5.csv: 50,000 rows
OP meds: 55 prescription(s) had only pack/course qty (DispensedQuantity/Quantity/Qty) and were not written as DOSE.
OP dispensed meds qty: 132776 rows
ActivityTransaction 269655 measured rows (VIDA-HIS). UnitPrice / invoice price is not written.
35_ActivityTransaction_p6.csv: 19,655 rows
35_ActivityTransaction.csv: 269,655 rows in 6 files
Facts extract finished

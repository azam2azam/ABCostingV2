﻿HIS extract (HISGENX)
Pack: facts
HIS SetupID: 010266
HIS ProjectID: 17
Period: 2026-09-01 .. 2026-09-10 inclusive
Extracted (UTC): 2026-11-10 11:42:55Z

Identity is SetupID + ProjectID (every CSV + zip name). Do not treat the zip
filename as a VERITA hospital. Inner CSV names stay NN_Table.csv.

Facts include 35_ActivityTransaction.csv from measured HIS clocks and quantities
(visit/ER/OR times, bed-days, floor stock, dispensed qty). Invoice price is not cost.
Import remaps SetupID-ProjectID codes onto the VERITA hospital you pick.

00_manifest.csv: 1 rows
Facts 2026-09-01 .. 2026-09-11 (SQL end exclusive)
32_Patient.csv: 20,456 rows
Drg on IP: 9522 admissions (0 from INP_AdmissionDRGList).
Drg on OP: 0 appointments from HIS_ApprovalDRG.
ER links by InvoiceNo: 52871.
ER links by AppointmentID: 57940.
ER encounters: 4071 linked by AppointmentID, 0 linked by InvoiceNo, 0 with no appointment. 0 AppointmentID values had no appointment for the same patient; 7 assessments shared an appointment with another.
33_Encounter.csv: 32,239 rows
36_RevenueTransaction.csv: 50,000 rows
34_EncounterService.csv: 50,000 rows
36_RevenueTransaction_p2.csv: 50,000 rows
34_EncounterService_p2.csv: 50,000 rows
Invoice lines with no appointment, admission or ER assessment, not loaded: 0.
RefundTransaction 1023 lines: 0 on cancelled refunds, 158 with no encounter. Not written as revenue.
37_RefundTransaction.csv: 1,023 rows
InvoicePackageItem 22541 lines: 0 with no encounter. Not written as services or revenue.
38_InvoicePackageItem.csv: 22,541 rows
36_RevenueTransaction_p3.csv: 36,246 rows
36_RevenueTransaction.csv: 136,246 rows in 3 files
34_EncounterService_p3.csv: 33,744 rows
34_EncounterService.csv: 133,744 rows in 3 files
OP visit minutes: 1184 rows
ER stay minutes: 12087 rows
OR / anaesthesia minutes: 12 rows
IP bed-days: 4362 rows
Floor consumption qty: 23453 rows
IP consumed items qty: 0 rows
35_ActivityTransaction.csv: 50,000 rows
OP meds: 21 prescription(s) had only pack/course qty (DispensedQuantity/Quantity/Qty) and were not written as DOSE.
OP dispensed meds qty: 44534 rows
ActivityTransaction 85632 measured rows (VIDA-HIS). UnitPrice / invoice price is not written.
35_ActivityTransaction_p2.csv: 35,632 rows
35_ActivityTransaction.csv: 85,632 rows in 2 files
Facts extract finished

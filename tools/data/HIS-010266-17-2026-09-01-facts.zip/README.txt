﻿HIS extract (HISGENX)
Pack: facts
HIS SetupID: 010266
HIS ProjectID: 17
Period: 2026-09-01 .. 2026-09-01 inclusive
Extracted (UTC): 2026-11-18 08:20:07Z

Identity is SetupID + ProjectID (every CSV + zip name). Do not treat the zip
filename as a VERITA hospital. Inner CSV names stay NN_Table.csv.

Facts are one zip per day. Utilization is raw/measured — not invented Activity×Resource:
39_ConsumptionItem.csv (item quantities), 40_StaffTime.csv (OR/OP/ER staff minutes),
41_EncounterTransfer.csv (INP_Transfer timing as stored). 35_ActivityTransaction.csv
is omitted (no ACT-/RES- invent from HIS clocks). Invoice price is not cost. Each day
carries every invoice (incl. claimed/settled/rejected), item and minute of the
encounters admitted or invoiced that day — encounter-driven, not only rows dated in
the window. Rows are keyed by sourceRef. Import remaps SetupID-ProjectID onto VERITA.

00_manifest.csv: 1 rows
Facts 2026-09-01 .. 2026-09-02 (SQL end exclusive)
32_Patient.csv: 3,234 rows
Drg on IP: 9976 admissions (0 from INP_AdmissionDRGList).
Drg on OP: 0 appointments from HIS_ApprovalDRG.
ER links by InvoiceNo: 55191.
ER links by AppointmentID: 60504.
ER encounters: 393 linked by AppointmentID, 0 linked by InvoiceNo, 0 with no appointment. 0 AppointmentID values had no appointment for the same patient; 2 assessments shared an appointment with another.
33_Encounter.csv: 3,775 rows
Billing: 131 admissions, 3641 appointments, 371 ER assessments in scope (6 s)
Billing encounter-driven: 25627 revenue lines (11668 with InvoiceDate outside the pack window). No encounter: 0.
RefundTransaction 225 lines (encounter-driven + in-window): 0 on cancelled refunds, 14 with no encounter. Not written as revenue.
37_RefundTransaction.csv: 225 rows
InvoicePackageItem 6889 lines (encounter-driven): 0 with no encounter. Not written as services or revenue.
38_InvoicePackageItem.csv: 6,889 rows
36_RevenueTransaction.csv: 25,627 rows
34_EncounterService.csv: 25,241 rows
Consumption: 131 admissions, 3641 appointments, 371 ER assessments in scope (7 s)
Consumption: 20095 counted invoice lines on the pack's encounters to link items to (5 s)
Consumption: 1869 item names from PHARMAKON.dbo.PHR_Item (23 s)
Floor consumption items: 6548 rows (9 s)
IP consumed items: 0 rows (1 s)
IP consumable log rows: 0 rows (0 s)
Implants skipped: Error converting data type varchar to bigint.
OP dispensed medicine: 5143 rows (7 s)
IP medicine orders: 0 rows (0 s)
Billed medicine lines: 307 rows
Billed oracle-linked consumable lines: 0 rows
Consumption: as-received HIS fields kept (TransType, prices, order keys). Returns not netted — Verita can net later. No ACT/RES invent.
39_ConsumptionItem.csv: 11,998 rows
OR staff minutes: 0 rows (0 s)
Implant scrub / circulating nurses: 0 rows (0 s)
Operative report nurses / techs: 0 rows (0 s)
Nursing procedure note clocks: 0 rows (0 s)
OP doctor minutes: 130 rows (0 s)
ER doctor / nurse minutes: 742 rows (1 s)
StaffTime: measured HIS clocks + named staff ids as received. Ward nursing standards are not invented — see 41_EncounterTransfer.csv.
40_StaffTime.csv: 872 rows
IP bed/ward transfers: 267 rows (0 s)
EncounterTransfer: INP_Transfer fields as received (timing, room/bed, doctors, status) — no minutes or patient-day conversion.
41_EncounterTransfer.csv: 267 rows
Facts extract finished (no invented ActivityTransaction ACT/RES volumes)

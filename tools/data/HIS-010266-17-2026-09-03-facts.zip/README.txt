﻿HIS extract (HISGENX)
Pack: facts
HIS SetupID: 010266
HIS ProjectID: 17
Period: 2026-09-03 .. 2026-09-03 inclusive
Extracted (UTC): 2026-11-18 08:24:06Z

Identity is SetupID + ProjectID (every CSV + zip name). Do not treat the zip
filename as a VERITA hospital. Inner CSV names stay NN_Table.csv.

Facts are one zip per day. Utilization is raw/measured — not invented Activity×Resource:
39_ConsumptionItem.csv (item quantities), 40_StaffTime.csv (OR/OP/ER staff minutes),
41_EncounterTransfer.csv (INP_Transfer timing as stored). 35_ActivityTransaction.csv
is omitted (no ACT-/RES- invent from HIS clocks). Invoice price is not cost. Each day
carries every invoice (incl. claimed/settled/rejected), item and minute of the
encounters admitted or invoiced that day — encounter-driven, not only rows dated in
the window. Rows are keyed by sourceRef. Import remaps SetupID-ProjectID onto VERITA.

00_manifest.csv: 1 rows
Facts 2026-09-03 .. 2026-09-04 (SQL end exclusive)
32_Patient.csv: 2,509 rows
Drg on IP: 9976 admissions (0 from INP_AdmissionDRGList).
Drg on OP: 0 appointments from HIS_ApprovalDRG.
ER links by InvoiceNo: 54432.
ER links by AppointmentID: 59694.
ER encounters: 399 linked by AppointmentID, 0 linked by InvoiceNo, 0 with no appointment. 0 AppointmentID values had no appointment for the same patient; 2 assessments shared an appointment with another.
33_Encounter.csv: 2,867 rows
Billing: 160 admissions, 2703 appointments, 374 ER assessments in scope (7 s)
Billing encounter-driven: 25156 revenue lines (12695 with InvoiceDate outside the pack window). No encounter: 0.
RefundTransaction 74 lines (encounter-driven + in-window): 0 on cancelled refunds, 15 with no encounter. Not written as revenue.
37_RefundTransaction.csv: 74 rows
InvoicePackageItem 7332 lines (encounter-driven): 0 with no encounter. Not written as services or revenue.
38_InvoicePackageItem.csv: 7,332 rows
36_RevenueTransaction.csv: 25,156 rows
34_EncounterService.csv: 24,806 rows
Consumption: 160 admissions, 2703 appointments, 374 ER assessments in scope (6 s)
Consumption: 19719 counted invoice lines on the pack's encounters to link items to (5 s)
Consumption: 1697 item names from PHARMAKON.dbo.PHR_Item (16 s)
Floor consumption items: 7603 rows (5 s)
IP consumed items: 0 rows (0 s)
IP consumable log rows: 0 rows (0 s)
Implants skipped: Error converting data type varchar to bigint.
OP dispensed medicine: 3857 rows (5 s)
IP medicine orders: 0 rows (0 s)
Billed medicine lines: 315 rows
Billed oracle-linked consumable lines: 1 rows
Consumption: as-received HIS fields kept (TransType, prices, order keys). Returns not netted — Verita can net later. No ACT/RES invent.
39_ConsumptionItem.csv: 11,776 rows
OR staff minutes: 1 rows (0 s)
Implant scrub / circulating nurses: 0 rows (1 s)
Operative report nurses / techs: 0 rows (0 s)
Nursing procedure note clocks: 0 rows (0 s)
OP doctor minutes: 86 rows (0 s)
ER doctor / nurse minutes: 748 rows (2 s)
StaffTime: measured HIS clocks + named staff ids as received. Ward nursing standards are not invented — see 41_EncounterTransfer.csv.
40_StaffTime.csv: 835 rows
IP bed/ward transfers: 334 rows (1 s)
EncounterTransfer: INP_Transfer fields as received (timing, room/bed, doctors, status) — no minutes or patient-day conversion.
41_EncounterTransfer.csv: 334 rows
Facts extract finished (no invented ActivityTransaction ACT/RES volumes)

﻿HIS extract (HISGENX)
Pack: facts
HIS SetupID: 010266
HIS ProjectID: 17
Period: 2026-11-01 .. 2026-11-01 inclusive
Extracted (UTC): 2026-11-17 12:23:55Z

Identity is SetupID + ProjectID (every CSV + zip name). Do not treat the zip
filename as a VERITA hospital. Inner CSV names stay NN_Table.csv.

Facts are one zip per day. They include 35_ActivityTransaction.csv from measured HIS
clocks and quantities, 39_ConsumptionItem.csv (consumables, implants, medicine by item)
and 40_StaffTime.csv (OR team, OP/ER doctor, ward nursing minutes). Quantities only:
invoice price is not cost. Each day carries every item and minute of the encounters
admitted or invoiced that day; rows are keyed by sourceRef, so re-sent rows update.
Import remaps SetupID-ProjectID codes onto the VERITA hospital you pick.

00_manifest.csv: 1 rows
Facts 2026-11-01 .. 2026-11-02 (SQL end exclusive)
32_Patient.csv: 3,476 rows
Drg on IP: 9927 admissions (0 from INP_AdmissionDRGList).
Drg on OP: 0 appointments from HIS_ApprovalDRG.
ER links by InvoiceNo: 36940.
ER links by AppointmentID: 40481.
ER encounters: 400 linked by AppointmentID, 0 linked by InvoiceNo, 0 with no appointment. 0 AppointmentID values had no appointment for the same patient; 5 assessments shared an appointment with another.
33_Encounter.csv: 4,077 rows
Invoice lines with no appointment, admission or ER assessment, not loaded: 0.
RefundTransaction 299 lines: 0 on cancelled refunds, 25 with no encounter. Not written as revenue.
37_RefundTransaction.csv: 299 rows
InvoicePackageItem 2637 lines: 0 with no encounter. Not written as services or revenue.
38_InvoicePackageItem.csv: 2,637 rows
36_RevenueTransaction.csv: 17,248 rows
34_EncounterService.csv: 16,995 rows
OP visit minutes: 127 rows (3 s)
ER stay minutes: 1092 rows (5 s)
OR / anaesthesia minutes: 6 rows (4 s)
IP bed-days: 700 rows (11 s)
Floor consumption qty: 1946 rows (2 s)
IP consumed items qty: 0 rows (0 s)
OP meds: 1 prescription(s) had only pack/course qty (DispensedQuantity/Quantity/Qty) and were not written as DOSE.
OP dispensed meds qty: 4908 rows (1 s)
ActivityTransaction 8779 measured rows (VIDA-HIS). UnitPrice / invoice price is not written.
35_ActivityTransaction.csv: 8,779 rows
Consumption: 157 admissions, 3908 appointments, 364 ER assessments in scope (8 s)
Consumption: 31219 counted invoice lines on the pack's encounters to link items to (11 s)
Floor consumption items: 12167 rows (12 s)
IP consumed items: 0 rows (1 s)
Implants skipped: Error converting data type varchar to bigint.
OP dispensed medicine: 5284 rows (6 s)
Billed medicine lines: 310 rows
Consumption: IP medicine is the billed quantity until the pharmacy dispense feed is joined. Billed consumable charge codes without an issue row are not written yet (category list to be confirmed).
39_ConsumptionItem.csv: 17,761 rows
OR staff minutes: 3 rows (1 s)
OP doctor minutes: 127 rows (0 s)
ER doctor / nurse minutes: 728 rows (1 s)
Ward nursing (standard): 350 rows (1 s)
StaffTime: ward nursing is patient-days × 260 min (STANDARD) until nursing supplies a standard per ward. ER minutes are the patient's stay.
40_StaffTime.csv: 1,208 rows
Facts extract finished

﻿HIS extract (HISGENX)
Pack: facts
HIS SetupID: 010266
HIS ProjectID: 15
Period: 2026-03-01 .. 2026-03-31 inclusive
Extracted (UTC): 2026-10-28 08:57:23Z
Server: RAY-VIDA-UAT

Identity is SetupID + ProjectID (every CSV + zip name). Do not treat the zip
filename as a VERITA hospital. Inner CSV names stay NN_Table.csv.

These packs are not yet importable into current VERITA Data import (extra
setupId/projectId columns + 00_manifest.csv). Copy the zips back for validation
before VERITA import is updated.

00_manifest.csv: 1 rows
Facts 2026-03-01 .. 2026-04-01 (SQL end exclusive)
32_Patient.csv: 100 rows
33_Encounter.csv: 397 rows
36_RevenueTransaction.csv: 479 rows
34_EncounterService.csv: 444 rows
Facts extract finished
